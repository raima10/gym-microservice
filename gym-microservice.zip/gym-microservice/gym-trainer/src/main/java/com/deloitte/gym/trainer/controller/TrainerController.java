package com.deloitte.gym.trainer.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.deloitte.gym.trainer.entity.Trainer;
import com.deloitte.gym.trainer.service.TrainerServiceImpl;

@RestController
@RequestMapping("/trainers")
public class TrainerController {
	
	@Autowired
	TrainerServiceImpl trainerserviceImpl;
	
	@GetMapping("/gettrainers")
	public ResponseEntity <List<Trainer>> getAllTrainer()
	{
		
		List<Trainer> trainers = trainerserviceImpl.getTrainers();
		return new ResponseEntity<List<Trainer>>(trainers, HttpStatus.OK);
		
	}
	
	@GetMapping("/getTrainer/{memberid}")
	public ResponseEntity<List<Trainer>> getOrderByMemberID(@PathVariable("memberid") Integer MemberID)
	{
		List<Trainer> trainer =trainerserviceImpl.getTrainer(MemberID);
		return new ResponseEntity<List<Trainer>>(trainer, HttpStatus.OK) ;
		
	}
	

}
