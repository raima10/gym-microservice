package com.deloitte.gym.trainer.service;

import java.util.List;

import com.deloitte.gym.trainer.entity.Trainer;

public interface TrainerService {
	
	public List<Trainer> getTrainers();
	
	public List<Trainer> getTrainer(Integer id);

}
