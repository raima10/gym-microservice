package com.deloitte.gym.trainer.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.deloitte.gym.trainer.entity.Trainer;

public interface TrainerRepository extends JpaRepository<Trainer, Integer> {
	public List<Trainer> findByMemberid(Integer memberid );
	

}
