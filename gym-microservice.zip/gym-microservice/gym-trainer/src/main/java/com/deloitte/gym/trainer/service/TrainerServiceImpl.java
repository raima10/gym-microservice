package com.deloitte.gym.trainer.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deloitte.gym.trainer.entity.Trainer;
import com.deloitte.gym.trainer.repo.TrainerRepository;


@Service
public class TrainerServiceImpl implements TrainerService {
	
	@Autowired
	TrainerRepository trainerRepository;

	@Override
	public List<Trainer> getTrainers() {
		// TODO Auto-generated method stub
		return trainerRepository.findAll();
	}

	@Override
	public List<Trainer> getTrainer(Integer id) {
		// TODO Auto-generated method stub
		return trainerRepository.findByMemberid(id);
	}

}
