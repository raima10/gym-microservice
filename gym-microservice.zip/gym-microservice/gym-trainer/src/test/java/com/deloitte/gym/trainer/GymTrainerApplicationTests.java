package com.deloitte.gym.trainer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GymTrainerApplicationTests {

	@Test
	void contextLoads() {
	}

}
