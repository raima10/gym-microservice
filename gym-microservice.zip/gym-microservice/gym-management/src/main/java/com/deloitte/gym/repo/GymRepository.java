package com.deloitte.gym.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.deloitte.gym.entity.Gym;


public interface GymRepository extends JpaRepository<Gym, Integer>{
	public List<Gym> findByMemberid(Integer memberid);
}

