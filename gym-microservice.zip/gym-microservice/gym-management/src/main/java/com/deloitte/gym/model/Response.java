package com.deloitte.gym.model;

import java.util.List;
import com.deloitte.gym.entity.Gym;

public class Response {
	
	private List<Gym> gymResponse;
	private List<Trainer> trainerResponse;
	
	public Response() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Response(List<Gym> gymResponse, List<Trainer> trainerResponse) {
		super();
		this.gymResponse = gymResponse;
		this.trainerResponse = trainerResponse;
	}

	public List<Gym> getGymResponse() {
		return gymResponse;
	}

	public void setGymResponse(List<Gym> gymResponse) {
		this.gymResponse = gymResponse;
	}

	public List<Trainer> getTrainerResponse() {
		return trainerResponse;
	}

	public void setTrainerResponse(List<Trainer> trainerResponse) {
		this.trainerResponse = trainerResponse;
	}
	
	

}
