package com.deloitte.gym.entity;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="members")
public class Gym {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer memberid;
	private Integer memberage;
	private String membername;
	
	
	public Gym() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Gym(Integer memberid, Integer memberage, String membername) {
		super();
		this.memberid = memberid;
		this.memberage = memberage;
		this.membername = membername;
	}


	public Integer getMemberid() {
		return memberid;
	}


	public void setMemberid(Integer memberid) {
		this.memberid = memberid;
	}


	public Integer getMemberage() {
		return memberage;
	}


	public void setMemberage(Integer memberage) {
		this.memberage = memberage;
	}


	public String getMembername() {
		return membername;
	}


	public void setMembername(String membername) {
		this.membername = membername;
	}
	
	
	
	
}
	
	
	
	


