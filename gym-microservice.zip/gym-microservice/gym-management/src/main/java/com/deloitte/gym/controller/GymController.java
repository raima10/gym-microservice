package com.deloitte.gym.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.deloitte.gym.entity.Gym;
import com.deloitte.gym.model.Response;
import com.deloitte.gym.model.Trainer;
import com.deloitte.gym.service.GymServiceImpl;

@RestController
@RequestMapping("/gyms")
public class GymController {
	
	@Autowired
	GymServiceImpl gymserviceImpl;
	
	@Autowired
	private RestTemplate restTemp;
	
	@GetMapping("/getgyms")
	public ResponseEntity <List<Gym>> getAllGym()
	{
		List<Gym> gyms = gymserviceImpl.getGyms();
		return new ResponseEntity<List<Gym>>(gyms, HttpStatus.OK);
	}
	
//	@GetMapping("/getgym/{memberid}")
//	public ResponseEntity<List<Gym>> getOrderByMemberID(@PathVariable("memberid")Integer MemberID)
//	{
//		List<Gym> gym = gymserviceImpl.getGym(MemberID);
//		return new ResponseEntity<List<Gym>>(gym, HttpStatus.OK);
//	}
	
	@GetMapping("/getgym/{memberid}")
	public ResponseEntity<Response> getOrderByMemberID(@PathVariable("memberid") Integer id)
	{
		List<Gym> gym = gymserviceImpl.getGym(id);
		List<Trainer> trainer = restTemp.getForObject("http://localhost:8083/trainers/getTrainer/"+id, List.class);
		
		Response res = new Response(gym, trainer);
		return new ResponseEntity<Response>(res, HttpStatus.OK);
	}
}
