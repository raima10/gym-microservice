package com.deloitte.gym.model;

public class Trainer {
	
	private Integer memberid;
	private String tname;
	private String pspeciality;
	
	public Trainer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Trainer(Integer memberid, String tname, String pspeciality) {
		super();
		this.memberid = memberid;
		this.tname = tname;
		this.pspeciality = pspeciality;
	}

	public Integer getMemberid() {
		return memberid;
	}

	public void setMemberid(Integer memberid) {
		this.memberid = memberid;
	}

	public String getTname() {
		return tname;
	}

	public void setTname(String tname) {
		this.tname = tname;
	}

	public String getPspeciality() {
		return pspeciality;
	}

	public void setPspeciality(String pspeciality) {
		this.pspeciality = pspeciality;
	}
	
	
	

}
