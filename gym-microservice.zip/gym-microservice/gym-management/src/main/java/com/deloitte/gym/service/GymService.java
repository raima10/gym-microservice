package com.deloitte.gym.service;

import java.util.List;

import com.deloitte.gym.entity.Gym;

public interface GymService {

	public List<Gym> getGyms();

	public List<Gym> getGym(Integer id);

}
