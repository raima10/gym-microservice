package com.deloitte.gym.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deloitte.gym.entity.Gym;
import com.deloitte.gym.repo.GymRepository;

@Service
public class GymServiceImpl implements GymService{
    
    @Autowired
    GymRepository gymRepository;
 
	@Override
	public List<Gym> getGyms() {
		// TODO Auto-generated method stub
		return gymRepository.findAll();
	}

	@Override
	public List<Gym> getGym(Integer id) {
		// TODO Auto-generated method stub
		return gymRepository.findByMemberid(id);
	}
    
}